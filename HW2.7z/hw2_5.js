
/**
 * Функция выполняет заданную операцию (+ - / * ) с заданными аргументами
 * @param {Number} arg1 
 * @param {Number} arg2 
 * @param {Number} operation 
 */
function mathOperation(arg1, arg2, operation) {
    switch (operation) {
        case "*":
            return multiply(arg1, arg2);
        case "/":
            return division(arg1, arg2);
        case "+":
            return pluss(arg1, arg2);
        case "-":
            return minus(arg1, arg2);
        default:
            return operation + " - такой оператор не предусмотрен";
    }
}