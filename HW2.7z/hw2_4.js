/**
 * Функция возвращает сумму
 * @param {number} operand1 
 * @param {number} operand2 
 * @returns {number}
 */
function pluss(operand1 = 0, operand2 = 0) {
    return operand1 + operand2;
}

/**
 * Функция возвращает разность
 * @param {number} operand1 
 * @param {number} operand2 
 * @returns {number}
 */
function minus(operand1 = 0, operand2 = 0) {
    return operand1 - operand2;
}


/**
 * Функция возвращает частное
 * @param {number} operand1 
 * @param {number} operand2 
 * @returns {number}
 */
function division(operand1 = 0, operand2 = 0) {
    return operand1 / operand2;
}


/**
 * Функция возвращает произведение
 * @param {number} operand1 
 * @param {number} operand2 
 * @returns {number}
 */
function multiply(operand1 = 0, operand2 = 0) {
    return operand1 * operand2;
}
